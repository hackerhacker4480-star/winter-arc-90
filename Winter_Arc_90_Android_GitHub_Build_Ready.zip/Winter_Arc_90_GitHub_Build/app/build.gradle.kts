plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.kg.winterarc90"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.kg.winterarc90"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
