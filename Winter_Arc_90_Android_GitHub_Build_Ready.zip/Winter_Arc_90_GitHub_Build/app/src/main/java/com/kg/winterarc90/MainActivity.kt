package com.kg.winterarc90

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class MainActivity : Activity() {
    private val tasks = listOf("उठणे + पाणी", "Walking – 30 मिनिटे", "Home Workout – 20 मिनिटे", "Stretching – 5 मिनिटे", "Protein / पौष्टिक आहार", "पाणी नियमित पिणे", "वेळेवर झोप")
    private lateinit var prefs: android.content.SharedPreferences
    private var selectedDay = 1
    private lateinit var dayLabel: TextView
    private lateinit var progress: ProgressBar
    private lateinit var countLabel: TextView
    private lateinit var taskBox: LinearLayout
    private lateinit var calendarBox: GridLayout
    private val bg = Color.rgb(11,16,12)
    private val panel = Color.rgb(21,29,23)
    private val green = Color.rgb(140,233,154)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("winter_arc", MODE_PRIVATE)
        val start = LocalDate.parse(prefs.getString("start_date", "2026-10-01"))
        selectedDay = (ChronoUnit.DAYS.between(start, LocalDate.now()).toInt() + 1).coerceIn(1,90)
        buildUi()
        render()
    }
    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,24,18,30); setBackgroundColor(bg) }
        scroll.addView(root)
        val title = TextView(this).apply { text="WINTER ARC 90  🔥\nKG • PERSONAL CHALLENGE"; textSize=22f; setTextColor(green); setTypeface(null,1) }
        root.addView(title)
        dayLabel = TextView(this).apply { textSize=32f; setTextColor(Color.WHITE); setPadding(0,22,0,8); setTypeface(null,1) }
        root.addView(dayLabel)
        progress = ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply { max=90; progressTintList=android.content.res.ColorStateList.valueOf(green); progressBackgroundTintList=android.content.res.ColorStateList.valueOf(Color.DKGRAY) }
        root.addView(progress, LinearLayout.LayoutParams(-1,18))
        countLabel = TextView(this).apply { textSize=14f; setTextColor(Color.LTGRAY); setPadding(0,8,0,18) }
        root.addView(countLabel)
        val stats = TextView(this).apply {
            text="Starting weight: ${prefs.getString("start_weight","68")} kg     Target: ${prefs.getString("target_weight","55")} kg"
            textSize=15f; setTextColor(Color.WHITE); setPadding(14,14,14,14); setBackgroundColor(panel)
        }
        root.addView(stats, LinearLayout.LayoutParams(-1,-2))
        addHeader(root,"आजची Checklist")
        taskBox=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,4,0,8) }; root.addView(taskBox)
        addHeader(root,"90 दिवसांचा Calendar")
        calendarBox=GridLayout(this).apply { columnCount=6; setPadding(0,4,0,10) }; root.addView(calendarBox)
        val settings = Button(this).apply { text="SETTINGS / START DATE"; setOnClickListener { editSettings() } }
        root.addView(settings)
        val backup = Button(this).apply { text="RESET TODAY'S CHECKLIST"; setOnClickListener { prefs.edit().remove(keyFor(selectedDay)).apply(); render() } }
        root.addView(backup)
        setContentView(scroll)
    }
    private fun addHeader(root: LinearLayout, text: String) {
        root.addView(TextView(this).apply { this.text=text; textSize=19f; setTextColor(green); setTypeface(null,1); setPadding(0,22,0,8) })
    }
    private fun keyFor(day:Int)="checks_$day"
    private fun checked(day:Int): MutableSet<String> = (prefs.getStringSet(keyFor(day), emptySet()) ?: emptySet()).toMutableSet()
    private fun render() {
        val set=checked(selectedDay)
        dayLabel.text="DAY %02d / 90".format(selectedDay)
        progress.progress=selectedDay
        countLabel.text="${selectedDay}% timeline • Checklist ${set.size}/7 • ${90-selectedDay} days to go"
        taskBox.removeAllViews()
        tasks.forEachIndexed { index, label ->
            val cb=CheckBox(this).apply {
                text=label; textSize=15f; setTextColor(Color.WHITE); buttonTintList=android.content.res.ColorStateList.valueOf(green)
                isChecked=set.contains(index.toString())
                setOnCheckedChangeListener { _, checked ->
                    val now=checked(selectedDay)
                    if(checked) now.add(index.toString()) else now.remove(index.toString())
                    prefs.edit().putStringSet(keyFor(selectedDay),now).apply()
                    countLabel.text="${selectedDay}% timeline • Checklist ${now.size}/7 • ${90-selectedDay} days to go"
                    WinterWidget.refresh(this@MainActivity)
                }
            }
            taskBox.addView(cb)
        }
        calendarBox.removeAllViews()
        for(day in 1..90) {
            val b=Button(this).apply {
                text=day.toString(); textSize=11f; minWidth=0; minimumWidth=0; setPadding(0,4,0,4)
                val complete=checked(day).size==7
                setTextColor(if(day==selectedDay) Color.BLACK else Color.WHITE)
                setBackgroundTintList(android.content.res.ColorStateList.valueOf(if(day==selectedDay) green else if(complete) Color.rgb(47,120,65) else panel))
                setOnClickListener { selectedDay=day; render() }
            }
            val lp=GridLayout.LayoutParams().apply { width=0; height=48; columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f); setMargins(3,3,3,3) }
            calendarBox.addView(b,lp)
        }
        WinterWidget.refresh(this)
    }
    private fun editSettings() {
        val input=EditText(this).apply { hint="Start date YYYY-MM-DD"; setText(prefs.getString("start_date","2026-10-01")) }
        AlertDialogBuilder.show(this,input) {
            val value=input.text.toString().trim()
            try { LocalDate.parse(value); prefs.edit().putString("start_date",value).apply(); selectedDay=(ChronoUnit.DAYS.between(LocalDate.parse(value),LocalDate.now()).toInt()+1).coerceIn(1,90); render() }
            catch (_:Exception) { Toast.makeText(this,"Date format YYYY-MM-DD वापरा",Toast.LENGTH_LONG).show() }
        }
    }
}
