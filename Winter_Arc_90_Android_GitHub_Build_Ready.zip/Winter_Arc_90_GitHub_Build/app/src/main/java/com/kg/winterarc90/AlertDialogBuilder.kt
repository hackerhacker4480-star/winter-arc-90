package com.kg.winterarc90
import android.app.AlertDialog
import android.content.Context
import android.widget.EditText
object AlertDialogBuilder {
    fun show(context: Context, input: EditText, onSave: () -> Unit) {
        AlertDialog.Builder(context).setTitle("Challenge start date").setMessage("Date format: YYYY-MM-DD").setView(input)
            .setPositiveButton("Save") { _, _ -> onSave() }.setNegativeButton("Cancel", null).show()
    }
}
