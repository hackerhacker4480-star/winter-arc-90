package com.kg.winterarc90

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class WinterWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val prefs = context.getSharedPreferences("winter_arc", Context.MODE_PRIVATE)
        val start = LocalDate.parse(prefs.getString("start_date", "2026-10-01"))
        val day = (ChronoUnit.DAYS.between(start, LocalDate.now()).toInt() + 1).coerceIn(1, 90)
        val checked = prefs.getStringSet("checks_$day", emptySet())?.size ?: 0
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.winter_widget)
            views.setTextViewText(R.id.widget_day, "DAY %02d / 90".format(day))
            views.setProgressBar(R.id.widget_progress, 90, day, false)
            views.setTextViewText(R.id.widget_done, "Checklist $checked/7 • Tap to open")
            val intent = Intent(context, MainActivity::class.java)
            val pi = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_title, pi)
            views.setOnClickPendingIntent(R.id.widget_day, pi)
            views.setOnClickPendingIntent(R.id.widget_done, pi)
            manager.updateAppWidget(id, views)
        }
    }
    companion object {
        fun refresh(context: Context) {
            val intent = Intent(context, WinterWidget::class.java).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
            val ids = AppWidgetManager.getInstance(context).getAppWidgetIds(android.content.ComponentName(context, WinterWidget::class.java))
            intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            context.sendBroadcast(intent)
        }
    }
}
