WINTER ARC 90 – KG (Android App + Home Screen Widget)

या प्रोजेक्टमध्ये:
- Native Android App
- Android Home Screen Widget
- 90 दिवसांची Checklist आणि Calendar
- प्रारंभिक वजन 68 kg आणि लक्ष्य 55 kg
- Checklist डेटा फोनमध्ये स्थानिकरीत्या साठवला जातो
- Challenge start date: 01-10-2026 (Day 1)

APK तयार करण्याचे पर्याय:
A) PC असल्यास Android Studio मध्ये project उघडून Build > Build APK(s).
B) फक्त Android फोन असल्यास BUILD_APK_FROM_ANDROID_MR.txt मधील GitHub Actions पद्धत वापरा. GitHub वर project upload केल्यानंतर server APK build करून Artifacts मध्ये देईल.

ही ZIP स्वतः APK नाही. तयार APK install केल्यानंतर Home Screen वर long press > Widgets > Winter Arc 90 निवडा.
